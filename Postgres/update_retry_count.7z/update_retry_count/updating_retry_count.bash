#!/bin/bash

#Step 9: Running the update query
echo 'Updating the retry count'
echo 'This is going to take some time'
cqlsh 10.138.32.80 -u cassandra -p cassandra -f /tmp/updatequery --request-timeout=20000
echo 'Update completed'