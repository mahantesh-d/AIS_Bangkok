#!/bin/bash

# Step 1: Add a new alternate column
echo 'Creating the retry_count_int as integer datatype'
cqlsh 10.138.32.80 -u cassandra -p cassandra -k alltrade_poc -e "ALTER TABLE alltrade_poc.local_service_requests_new6 ADD retry_count_int int" --request-timeout=20000


# Step 2: Take a backup of the whole table
echo 'Taking the snapshot of the orginal table'
nodetool snapshot alltrade_poc.local_service_requests_new6

# Step 3: Take a backup of the whole table
echo 'Taking the backup of the schema'
cqlsh 10.138.32.80 -u cassandra -p cassandra -k alltrade_poc -e "DESCRIBE local_service_requests_new6" > /tmp/schema_local_service_requests_new8.cql

# Step 4: Create a reference file with retry_count and pk values so we can use this for Step . 
echo 'Creating the file query in tmp containg the select of retry_count and pk'
cat > /tmp/query <<EOF
SELECT retry_count,local_service_requests_new6_pk from alltrade_poc.local_service_requests_new6;
EOF

# Step 5: Run the query from the previous step
echo 'Storing the output of query file in /tmp/query_out'
cqlsh 10.138.32.80 -u cassandra -p cassandra -k alltrade_poc -f /tmp/query > /tmp/query_out --request-timeout=20000


# Step 6: Generate the retry count query file
echo 'Creating the update queries'
cat /tmp/query_out | tail -n+4 | head -n-2 | awk '{ gsub("[a-zA-z].*", "0" ,$1); print "UPDATE alltrade_poc.local_service_requests_new6 set retry_count = ",$1,"WHERE local_service_requests_new6_pk = " $3  }' | sed 's/$/;/' > /tmp/updatequery
echo 'Created update queries'

echo '*************************** Check the files and Procceed to pre_update2 ***************************'